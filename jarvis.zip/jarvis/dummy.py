import pyttsx3
engine = pyttsx3.init('sapi5')  # for Windows
engine.say("Testing SAPI5 voice.")
engine.runAndWait()
