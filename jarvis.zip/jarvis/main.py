import pyttsx3
import webbrowser
import pywhatkit
import wikipedia
import pyjokes
import datetime
import sys

engine = pyttsx3.init('sapi5')


voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)   
engine.setProperty('rate', 170)             

def speak(text):
    engine.say(text)
    engine.runAndWait()

def greet():
    
    hour = datetime.datetime.now().hour
    if hour < 12:
        speak("Good morning sir!")
    elif hour < 18:
        speak("Good afternoon sir!")
    else:
        speak("Good evening sir!")
    speak("Jarvis online and ready!")

def take_command():
  
    query = input("You: ").lower()
    return query

def main():
    greet()  
    while True:
        command = take_command()

        if command.strip() == "":
            speak("You didn't type anything, sir.")
            continue

     
        speak(f"You said: {command}")

      
        if "time" in command:
            time = datetime.datetime.now().strftime("%I:%M %p")
            speak(f"Executing command. The time is {time}")

        elif "date" in command:
            date = datetime.datetime.now().strftime("%B %d, %Y")
            speak(f"Executing command. Today's date is {date}")

        elif "open youtube" in command:
            speak("Executing command. Opening YouTube now.")
            webbrowser.open("https://youtube.com")

        elif "open google" in command:
            speak("Executing command. Opening Google now.")
            webbrowser.open("https://google.com")

        elif "play" in command:
            song = command.replace("play", "")
            speak(f"Executing command. Playing {song} on YouTube.")
            pywhatkit.playonyt(song)

        elif "wikipedia" in command:
            topic = command.replace("wikipedia", "")
            speak(f"Executing command. Searching Wikipedia for {topic}.")
            info = wikipedia.summary(topic, sentences=2)
            speak(info)

        elif "joke" in command:
            speak("Executing command. Here's a joke for you.")
            joke = pyjokes.get_joke()
            speak(joke)

        elif "exit" in command or "quit" in command:
            speak("Goodbye sir, have a great day!")
            sys.exit()

        else:
            speak("Sorry, I didn't understand that. Please try again.")

if __name__ == "__main__":
    main()


